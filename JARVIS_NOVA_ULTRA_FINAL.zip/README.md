# JARVIS + NOVA ULTRA (Android starter project)

An Android Java starter app with two separate assistant screens, separate conversation stores, Gemini API-key settings encrypted with Android Keystore, TTS voice selection when the device exposes gender-labelled voices, and an opt-in microphone foreground service for spoken wake-name detection.

## Build APK with GitHub Actions
1. Create a GitHub repository.
2. Upload the **contents** of this project folder (not a ZIP nested inside the repository).
3. Open Actions and run **Build JARVIS + NOVA ULTRA APK**.
4. Download the `JARVIS-NOVA-ULTRA-debug-apk` artifact from the completed workflow.

## Run locally
Open this folder in Android Studio and build `app` > `assembleDebug`. Java 17 and Android SDK platform/build tools 35 are used by the workflow.

## Setup
1. Install the APK and open the app.
2. Tap Settings, paste your Gemini API key, and save it. The key is encrypted using Android Keystore on this device.
3. Test the connection.
4. Grant microphone permission and tap Start Wake-Word Listening if you want the optional listener.
5. Use the bottom navigation to open the separate JARVIS and NOVA pages.

## Important wake-word limitations
The wake-word service is an **experimental prototype** using Android's system SpeechRecognizer in a foreground microphone service. It is not an embedded always-on keyword model. SpeechRecognizer providers and phone manufacturers may suspend or stop recognition when the screen is off, under battery optimization, or when the device is locked. Android may also restrict launching an Activity from the background; in that case the notification updates and the user can tap it to open the detected assistant. For reliable commercial-grade always-on hotword detection, integrate a licensed on-device keyword-spotting engine and test against the target phone's Android/OEM policies.

The service is opt-in, displays an ongoing microphone notification, and can be stopped from that notification or Settings. Audio is not uploaded by the wake-word service; the app sends typed/recognized user prompts to Gemini only after the user submits them.

## Current capabilities and boundaries
- JARVIS and NOVA have separate local conversation histories and different persona prompts.
- API key is stored encrypted on-device; this is suitable for a personal prototype, not a shared/public app. Never commit API keys to GitHub.
- Voice gender depends on the installed Android TTS engine; not every phone provides selectable male/female voices.
- This starter does not provide unrestricted phone control, automatic WhatsApp sending, or hidden background recording. Add integrations individually with Android permissions and user confirmation.
